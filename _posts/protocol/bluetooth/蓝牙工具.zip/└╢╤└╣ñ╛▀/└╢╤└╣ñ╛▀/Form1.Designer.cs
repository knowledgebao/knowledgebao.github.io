﻿namespace 蓝牙工具
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_scan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.mac_address = new System.Windows.Forms.TextBox();
            this.info = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_conn = new System.Windows.Forms.Button();
            this.btn_date = new System.Windows.Forms.Button();
            this.btn_disconn = new System.Windows.Forms.Button();
            this.dev_name = new System.Windows.Forms.TextBox();
            this.btn_del = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_scan
            // 
            this.btn_scan.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_scan.Location = new System.Drawing.Point(49, 69);
            this.btn_scan.Name = "btn_scan";
            this.btn_scan.Size = new System.Drawing.Size(164, 46);
            this.btn_scan.TabIndex = 0;
            this.btn_scan.Text = "1.发现设备";
            this.btn_scan.UseVisualStyleBackColor = true;
            this.btn_scan.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(524, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "输入需要连接的MAC地址:";
            // 
            // mac_address
            // 
            this.mac_address.Font = new System.Drawing.Font("宋体", 12F);
            this.mac_address.Location = new System.Drawing.Point(714, 165);
            this.mac_address.Name = "mac_address";
            this.mac_address.Size = new System.Drawing.Size(162, 26);
            this.mac_address.TabIndex = 2;
            this.mac_address.Text = "a4:c1:38:45:68:f1";
            // 
            // info
            // 
            this.info.Font = new System.Drawing.Font("宋体", 12F);
            this.info.FormattingEnabled = true;
            this.info.ItemHeight = 16;
            this.info.Location = new System.Drawing.Point(49, 203);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(970, 388);
            this.info.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(50, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "请输入要过滤的设备名称:";
            // 
            // btn_conn
            // 
            this.btn_conn.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_conn.Location = new System.Drawing.Point(248, 69);
            this.btn_conn.Name = "btn_conn";
            this.btn_conn.Size = new System.Drawing.Size(162, 46);
            this.btn_conn.TabIndex = 4;
            this.btn_conn.Text = "2.连接设备";
            this.btn_conn.UseVisualStyleBackColor = true;
            this.btn_conn.Click += new System.EventHandler(this.btn_conn_ClickAsync);
            // 
            // btn_date
            // 
            this.btn_date.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_date.Location = new System.Drawing.Point(449, 69);
            this.btn_date.Name = "btn_date";
            this.btn_date.Size = new System.Drawing.Size(162, 46);
            this.btn_date.TabIndex = 5;
            this.btn_date.Text = "3.获取数据";
            this.btn_date.UseVisualStyleBackColor = true;
            this.btn_date.Click += new System.EventHandler(this.btn_date_Click);
            // 
            // btn_disconn
            // 
            this.btn_disconn.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_disconn.Location = new System.Drawing.Point(657, 69);
            this.btn_disconn.Name = "btn_disconn";
            this.btn_disconn.Size = new System.Drawing.Size(162, 46);
            this.btn_disconn.TabIndex = 6;
            this.btn_disconn.Text = "4.断开连接";
            this.btn_disconn.UseVisualStyleBackColor = true;
            this.btn_disconn.Click += new System.EventHandler(this.btn_disconn_Click);
            // 
            // dev_name
            // 
            this.dev_name.Font = new System.Drawing.Font("宋体", 12F);
            this.dev_name.Location = new System.Drawing.Point(248, 165);
            this.dev_name.Name = "dev_name";
            this.dev_name.Size = new System.Drawing.Size(197, 26);
            this.dev_name.TabIndex = 7;
            this.dev_name.Text = "LYWSD03MMC";
            // 
            // btn_del
            // 
            this.btn_del.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_del.Location = new System.Drawing.Point(857, 71);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(162, 46);
            this.btn_del.TabIndex = 8;
            this.btn_del.Text = "5. 清空数据";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F);
            this.label3.Location = new System.Drawing.Point(832, 611);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(224, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "配合\"米家蓝牙温湿度计2\"使用";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 636);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_del);
            this.Controls.Add(this.dev_name);
            this.Controls.Add(this.btn_disconn);
            this.Controls.Add(this.btn_date);
            this.Controls.Add(this.btn_conn);
            this.Controls.Add(this.info);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mac_address);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_scan);
            this.Name = "Form1";
            this.Text = "蓝牙(ble)扫描工具";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_scan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox mac_address;
        private System.Windows.Forms.ListBox info;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_conn;
        private System.Windows.Forms.Button btn_date;
        private System.Windows.Forms.Button btn_disconn;
        private System.Windows.Forms.TextBox dev_name;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Label label3;
    }
}

