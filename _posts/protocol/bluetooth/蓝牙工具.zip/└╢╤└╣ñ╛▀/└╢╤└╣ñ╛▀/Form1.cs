﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Windows.Devices.Enumeration;
using Windows.Devices.Bluetooth.Advertisement;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using System.Text.RegularExpressions;
using System.Activities.Expressions;

namespace 蓝牙工具
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // 保存搜索到的数据
        Dictionary<string, DeviceInformation> BleDevice = new Dictionary<string, DeviceInformation>();

        // 连接到的设备
        BluetoothLEDevice bluetoothLeDevice;
        // 扫描对象
        DeviceWatcher deviceWatcher;
        //订阅对象
        public GattCharacteristic characteristic;

        //正则返回格式化后的mac地址
        private static string showMatch(string text, string expr)
        {
            MatchCollection mc = Regex.Matches(text, expr);
            Match m = mc[0];
            return m.Groups[3].Value;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //按钮禁用
            //btn_scan.Enabled = false;
            //清空info_list
            info.Items.Clear();

            // 过滤设备名称
            string d_name = dev_name.Text;

            info.Items.Add("搜索中...(完整搜索大约一分钟)");
            // 搜索:
            scan();
        }

        
        public void scan() {
            // Query for extra properties you want returned
            string[] requestedProperties = { "System.Devices.Aep.DeviceAddress", "System.Devices.Aep.IsConnected" };

            deviceWatcher =
                        DeviceInformation.CreateWatcher(
                                BluetoothLEDevice.GetDeviceSelectorFromPairingState(false),
                                requestedProperties,
                                DeviceInformationKind.AssociationEndpoint);

            // Register event handlers before starting the watcher.
            // Added, Updated and Removed are required to get all nearby devices
            deviceWatcher.Added += DeviceWatcher_Added;
            deviceWatcher.Updated += DeviceWatcher_Updated;
            deviceWatcher.Removed += DeviceWatcher_Removed;

            // EnumerationCompleted and Stopped are optional to implement.
            //deviceWatcher.EnumerationCompleted += DeviceWatcher_EnumerationCompleted;
            deviceWatcher.Stopped += DeviceWatcher_Stopped;

            // Start the watcher.
            deviceWatcher.Start();
        }
        private void DeviceWatcher_Stopped(DeviceWatcher sender, object args)
        {
            //info.Items.Add("扫描完成...");


        }

        public delegate void DevInvoke(DeviceInformation dev);//invoke方法创建委托
        public async void add_info(DeviceInformation dev) {
            // 过滤设备名称
            string d_name = dev_name.Text.Trim();
            //BluetoothLE#BluetoothLEb4:69:21:8e:79:c4-fa:1e:91:f2:5f:c8
            string pattern = @"^BluetoothLE#BluetoothLE([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})-(([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2}))";
            string macId = showMatch(dev.Id, pattern);
            if (string.IsNullOrEmpty(d_name))
            {
                if (! BleDevice.ContainsKey(macId)) {
                    info.Items.Add("DeviceId: [" + dev.Id + "], DeviceName: " + dev.Name);
                    // 添加到匹配字典
                    
                    BleDevice[macId] = dev;
                }
                
            }
            else if (d_name == dev.Name)
            {
                
                if (!BleDevice.ContainsKey(macId))
                {
                    info.Items.Add("DeviceId: [" + dev.Id + "], DeviceName: " + dev.Name);
                    // 添加到匹配字典
                    BleDevice[macId] = dev;
                }
            }
        }

        public static StringBuilder ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("0x{0:x2}   ", b);
            return hex;
        }

        private void DeviceWatcher_Removed(DeviceWatcher sender, DeviceInformationUpdate args)
        {
            Console.WriteLine(args.Id+ args.Kind);
        }

        private void DeviceWatcher_Updated(DeviceWatcher sender, DeviceInformationUpdate args)
        {

        }

        private void DeviceWatcher_Added(DeviceWatcher sender, DeviceInformation args)
        {
            DevInvoke add_dev = new DevInvoke(add_info);
            BeginInvoke(add_dev, args);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dev_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            info.Items.Clear();

        }

        private async void btn_conn_ClickAsync(object sender, EventArgs e)
        {


            string mac_id = mac_address.Text.ToLower().Trim();
            //mac_id =  "A4:C1:38:45:68:F1".ToLower().Trim();
            info.Items.Clear();
            info.Items.Add("正在连接: "+ mac_id);

            // 获取dev
            try
            {
                DeviceInformation dev = BleDevice[mac_id];
                // Note: BluetoothLEDevice.FromIdAsync must be called from a UI thread because it may prompt for consent.
                bluetoothLeDevice = await BluetoothLEDevice.FromIdAsync(dev.Id);
                info.Items.Add("连接成功...");
            }
            catch(Exception ) {
                info.Items.Add("没有该设备, 请先扫描设备...");
            }
            


        }


        private async void btn_date_Click(object sender, EventArgs e)
        {
            info.Items.Add("正在获取服务...");
            try {
                GattDeviceServicesResult conn = await bluetoothLeDevice.GetGattServicesAsync();
                if (conn.Status == GattCommunicationStatus.Success)
                {
                    var services = conn.Services;
                    // ...
                    foreach (var service in services)
                    {
                        info.Items.Add("service uuid: " + service.Uuid);

                        GattCharacteristicsResult result = await service.GetCharacteristicsAsync();
                        if (result.Status == GattCommunicationStatus.Success)
                        {
                            var characteristics = result.Characteristics;
                            foreach (var chat in characteristics)
                            {
                                characteristic = chat;
                                info.Items.Add("chat: " + chat.Uuid + "     " + chat.AttributeHandle + "       " + chat.CharacteristicProperties);
                                if (chat.CharacteristicProperties.ToString().Contains("Read")) {
                                    GattReadResult c_result = await chat.ReadValueAsync();
                                    if (c_result.Status == GattCommunicationStatus.Success)
                                    {
                                        var reader = DataReader.FromBuffer(c_result.Value);
                                        byte[] input = new byte[reader.UnconsumedBufferLength];
                                        reader.ReadBytes(input);
                                        // Utilize the data as needed
                                        info.Items.Add("read value: " + String.Join("", input));
                                    }
                                }

                                if (chat.AttributeHandle.ToString().Equals("53"))
                                {
                                    GattCommunicationStatus status = await chat.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);
                                    if (status == GattCommunicationStatus.Success)
                                    {
                                        // Server has been informed of clients interest.
                                        info.Items.Add("订阅成功...");
                                        chat.ValueChanged += Characteristic_ValueChanged;
                                        // ... 
                                    }
                                }

                            }
                        }

                    }
                }
                else
                {
                    info.Items.Add("获取服务失败,请重新连接...");
                    bluetoothLeDevice.Dispose();

                }

            }
            catch(Exception ){
                info.Items.Add("获取服务失败,请重新连接/扫描设备...");
            }
            
           
        }
        public delegate void infoInvoke(String info);//invoke方法创建委托
        public async void updateInfo(String str) {
            info.Items.Add(str);
        }
        void Characteristic_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args){
            // An Indicate or Notify reported that the value has changed.
            var reader = DataReader.FromBuffer(args.CharacteristicValue);
            reader.UnicodeEncoding = Windows.Storage.Streams.UnicodeEncoding.Utf8;
            reader.ByteOrder = Windows.Storage.Streams.ByteOrder.LittleEndian;

            // Parse the data however required.
            byte[] data = new byte[reader.UnconsumedBufferLength];
            reader.ReadBytes(data);
            var temp_ = "0x"+Convert.ToString(data[1], 16) + Convert.ToString(data[0], 16);
            int result = Convert.ToInt32(temp_, 16);
            //int result = int.Parse("09c3", System.Globalization.NumberStyles.AllowHexSpecifier);
            
            String msg = "length:" + args.CharacteristicValue.Length + ",  时间: " + args.Timestamp + " ,湿度:" + data[2] + "%  ,温度:" + (result/100.0) + "℃";
            Console.WriteLine(msg);
            infoInvoke updateinfo = new infoInvoke(updateInfo);
            BeginInvoke(updateinfo, msg);


        }

        private async void btn_disconn_Click(object sender, EventArgs e)
        {
            info.Items.Add("正在断开....");
            
            //取消订阅
            if (characteristic != null) {
                GattCommunicationStatus status = await characteristic.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.None);
                
                if (status == GattCommunicationStatus.Success)
                {
                    // Server has been informed of clients interest.
                    characteristic.ValueChanged -= Characteristic_ValueChanged;
                    characteristic = null;
                    info.Items.Add("取消订阅...");
                }
            }

            //连接对象
            if (bluetoothLeDevice != null)
            {
                bluetoothLeDevice.Dispose();
                bluetoothLeDevice = null;
                
            }

            // 扫描对象
            if (deviceWatcher != null && deviceWatcher.Status == DeviceWatcherStatus.Started)
            {
                deviceWatcher.Stop();
                deviceWatcher = null;
                
            }

            if (bluetoothLeDevice != null)
            {
                bluetoothLeDevice.Dispose();
                bluetoothLeDevice = null;
            }

            BleDevice = new Dictionary<string, DeviceInformation>();
            info.Items.Add("已断开....");
            // 清空输出
             info.Items.Clear();
        }

    }
}
